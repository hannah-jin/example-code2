/**
 * Take operands from  FracCalc and create a fraction object; write toString method to print properly
 *
 * @author Hannah Jin
 * @version Final
 */
public class Fraction
{
    private int whole = 0;
    private int numer = 0;
    private int denom = 1;
    /**
     * Constructor for objects of class Fraction
     * 
     * @param the numerator and denominator of a fraction in improper form
     */
    public Fraction(int fNumer, int fDenom)
    {
        numer = fNumer;
        denom = fDenom;
    }
    
    /**
     * Adding two fractions: 1/2 + 1/2 returns 4/4
     * 
     * @param the numerator and denominator of a fraction in improper form
     * @return the sum of frac1 and frac2
     */
    public String add(Fraction frac2)
    {
        int num = numer * frac2.denom + frac2.numer * denom;
        int den = denom * frac2.denom;
        Fraction result = new Fraction(num, den);
        result.reduce();
        result.toWhole();
        return result.toString();
    }
    
    /**
     * Subtracting two fractions: 1/2 - 1/4 returns 2/8
     * 
     * @param the numerator and denominator of a fraction in improper form
     * @return the difference between frac1 and frac2
     */
    public String subtract(Fraction frac2)
    {
        int num = numer * frac2.denom - frac2.numer * denom;
        int den = denom * frac2.denom;
        Fraction result = new Fraction(num, den);
        result.reduce();
        result.toWhole();
        return result.toString();
    }
    
    /**
     * Multiplying two fractions: 1/2 * 1/2 returns 1/4
     * 
     * @param the numerator and denominator of a fraction in improper form
     * @return the product of frac1 and frac2
     */
    public String multiply(Fraction frac2)
    {
        int num = numer * frac2.numer;
        int den = denom * frac2.denom;
        Fraction result = new Fraction(num, den);
        result.reduce();
        result.toWhole();
        return result.toString();
    }
    
    /**
     * Dividing two fractions: 1/2 / 1/2 returns 2/2
     * 
     * @param the numerator and denominator of a fraction in improper form
     * @return the quotient of frac1 and frac2
     */
    public String divide(Fraction frac2)
    {
        int num = numer * frac2.denom;
        int den = denom * frac2.numer;
        Fraction result = new Fraction(num, den);
        result.reduce();
        result.toWhole();
        return result.toString();
    }
    
    /**
     * Finding the GCD of the fractions to reduce them
     * 
     */
    public void reduce()
    {
        int gcd = 1;
        for(int i = 1; i <= Math.abs(numer) && i <= Math.abs(denom); i++)
        {
            if(numer % i == 0 && denom % i == 0)
            {
                gcd = i;
            }
        }
        numer /= gcd;
        denom /= gcd;
    }
    
    /**
     * Turning the fractions into mixed fractions from improper ones
     * 
     */
    public void toWhole()
    {
        whole = numer / denom;
        numer = numer % denom;
        if(denom < 0)
        {  
            denom *= -1;
            numer *= -1;
        }
        if(whole != 0 && numer < 0)
        {
            numer *= -1;
        }
    }
    
    /**
     * returns the answer
     * 
     * @return a fraction in the form of String that is in mixed form and fully simplified
     */    
    public String toString()
    {
        if(whole == 0 && numer == 0)
        {
            return "0";
        }
        else if(whole != 0 && numer == 0)
        {
            return whole + "";
        }
        else if(whole == 0 && numer != 0)
        {
            return numer + "/" + denom;
        }
        else
        {
            return whole + "_" + numer + "/" + denom;
        }
    }
}
