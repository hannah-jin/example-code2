import java.util.Scanner;
/**
 * Add, subtract, multiply, and divide fractions.
 * 
 * @author Hannah Jin
 * @version Final
 */

public class FracCalc 
{
    /**
     * 
     * Take input from the user and print out the answer to the equuation they input
     */
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your operation:");
        String operation = input.nextLine();
        while(!operation.equals("quit"))
        {
            System.out.println(produceAnswer(operation));
            System.out.println("Enter your operation:");
            operation = input.nextLine();
        }
    }

    /**
     * Takes the input, splits it the whole, numerator, denominator of both fractions and the operator, and performs the operator and returns the answer
     * 
     * @param the operation that the user input
     * @return the final answer as a mixed and fully simplified fraction
     */
    public static String produceAnswer(String input)
    {
        //finding the whole, numerator, and denominator components of the first fraction
        int fSpace = input.indexOf(" ");
        String fValue = input.substring(0, fSpace);
        String whole1, numer1, denom1;
        int underscore1 = fValue.indexOf("_");
        int slash1 = fValue.indexOf("/");
        if(underscore1 > 0)
        {
            whole1 = fValue.substring(0, underscore1);
        }
        else if(underscore1 < 0 && slash1 < 0)
        {
            whole1 = fValue;
        }
        else
        {
            whole1 = "0";
        }
        if(slash1 > 0 && underscore1 > 0)
        {
            numer1 = fValue.substring(underscore1 + 1, slash1);
        }
        else if(slash1 > 0 && underscore1 < 0)
        {
            numer1 = fValue.substring(0, slash1);
        }
        else
        {
            numer1 = "0";
        }
        if(slash1 > 0)
        {
            denom1 = fValue.substring(slash1 + 1);
        }
        else
        {
            denom1 = "1";
        }
        String fComponents = "whole:" + whole1 + " numerator" + numer1 + " denominator" + denom1;
        
        //parsing the components to convert them from strings to integers and creating Fraction objects
        Fraction f1;
        if(Integer.parseInt(whole1) == 0  && fValue.indexOf("-") == 0)
        {
            f1 = new Fraction(Integer.parseInt(numer1), Integer.parseInt(denom1));
        }
        else if(fValue.indexOf("-") != -1)
        {
            f1 = new Fraction(Integer.parseInt(whole1) * Integer.parseInt(denom1) - Integer.parseInt(numer1), Integer.parseInt(denom1));
        }
        else
        {
            f1 = new Fraction(Integer.parseInt(whole1) * Integer.parseInt(denom1) + Integer.parseInt(numer1), Integer.parseInt(denom1));  
        }
        
        //finding the whole, numerator, and denominator components of the second fraction
        int sSpace = fSpace + 1 + input.substring(fSpace + 1).indexOf(" ");
        String operator = input.substring(fSpace+1, sSpace);
        String sValue = input.substring(sSpace + 1);
        String whole2, numer2, denom2;
        int underscore2 = sValue.indexOf("_");
        int slash2 = sValue.indexOf("/");
        if(underscore2 > 0)
        {
            whole2 = sValue.substring(0, underscore2);
        }
        else if(underscore2 < 0 && slash2 < 0)
        {
            whole2 = sValue;
        }
        else
        {
            whole2 = "0";
        }
        if(slash2 > 0 && underscore2 > 0)
        {
            numer2 = sValue.substring(underscore2 + 1, slash2);
        }
        else if(slash2 > 0 && underscore2 < 0)
        {
            numer2 = sValue.substring(0, slash2);
        }
        else
        {
            numer2 = "0";
        }
        if(slash2 > 0)
        {
            denom2 = sValue.substring(slash2 + 1);
        }
        else
        {
            denom2 = "1";
        }
        String sComponents = "whole:" + whole2 + " numerator:" + numer2 + " denominator:" + denom2;
        
        //parsing the components to convert them from strings to integers and creating Fraction objects
        Fraction f2;
        if(Integer.parseInt(whole2) == 0  && sValue.indexOf("-") == 0)
        {
            f2 = new Fraction(Integer.parseInt(numer2), Integer.parseInt(denom2));
        }
        else if(sValue.indexOf("-")!=-1)
        {
            f2 = new Fraction(Integer.parseInt(whole2) * Integer.parseInt(denom2) - Integer.parseInt(numer2), Integer.parseInt(denom2));
        }
        else
        {
            f2 = new Fraction(Integer.parseInt(whole2) * Integer.parseInt(denom2) + Integer.parseInt(numer2), Integer.parseInt(denom2));  
        }
        
        //determining which Fraction method will need to be used (addition, subtraction, multiplication, or division)
        if (operator.equals("+")) 
        {
            return (f1.add(f2));
        }
        else if (operator.equals("-")) 
        {
            return (f1.subtract(f2));
        }
        else if (operator.equals("*")) 
        {
            return (f1.multiply(f2));
        }
        else 
        {
            return (f1.divide(f2));
        }
    }
}